// 用户头像修改
$("#avatar").change(function () {
    // 获取用户选择的文件对象
    var file_obj = $(this)[0].files[0];
    // 获取文件对象路径
    var reader = new FileReader();
    reader.readAsDataURL(file_obj);
    // 修改img的src属性 src= 文件对象的路径
    reader.onload = function () {
        $("#avatar_img").attr("src", reader.result);
    };
});

// 绑定数据提交事件 注册
$(".register").click(function () {
    var form_data = new FormData()
    var request_data = $("#form").serializeArray();
    $.each(request_data, function (index, data) {
        form_data.append(data.name, data.value)
    });
    form_data.append("avatar", $("#avatar")[0].files[0])
    $.ajax({
        url: "",
        type: "post",
        contentType: false,
        processData: false,
        data: form_data,
        success: function (data) {
            if (data.user) {
                //注册成功
                location.href = "/login/"
            } else {
                // 注册失败
                // 清空错误信息
                $("span.error").html("");
                $(".form-group").removeClass("has-error");

                // 展此次提交的错误信息!
                $.each(data.msg, function (field, error_list) {
                    console.log(field, error_list);
                    if (field == "__all__") {
                        $("#id_re_password").next().html(error_list[0]).parent().addClass("has-error");
                    }
                    $("#id_" + field).next().html(error_list[0]);
                    $("#id_" + field).parent().addClass("has-error");


                });
            }


        }
    })
});