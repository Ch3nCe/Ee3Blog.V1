// 点击刷新验证码
$("#valid_code_img").click(function () {
    $(this)[0].src += '?';
});

// 登录验证
$(".login").click(function () {
    $.ajax({
        url:"",
        type:"post",
        data:{
            username:$("#username").val(),
            password:$("#password").val(),
            valid_code:$("#valid_code").val(),
            csrfmiddlewaretoken:$("[name='csrfmiddlewaretoken']").val(),
        },
        success:function (data) {
            console.log(data)
            if (data.user){
                if (location.search){
                    location.href = location.search.slice(6)
                }else {
                    location.href = "/index/"
                }
            }else {
                $(".error").text(data.msg).css({
                    "color":"red",
                })
                setTimeout(function () {
                    $(".error").text("")
                },2000)
            }
        }
    })
});